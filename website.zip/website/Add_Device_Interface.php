<!DOCTYPE html>
<?php
    include("session.php");
?>
<html>

<head>
    <link rel="stylesheet" media="screen and (max-width: 1000px)" href="css/index-style.css">
    <link rel="stylesheet" media="screen and (max-width: 1500px)" href="css/index-style-max.css">
</head>

<body>


    <div id="mainContainer">

        <div id="interface">
            <div id="header">
                <div>
                    <div class="menu">
                        <!-- <img src="icons/menu.png" class="idCardIcon"> -->
                    </div>

                    <div id="inner-header">
                        <a id="header-text">Network Limiter</a>
                    </div>

                    <div class="admIcon">
                        <figure>
                            <img src="icons/user.png" class="idCardIcon">
                            <figcaption>Admin</figcaption>
                        </figure>
                    </div>
                </div>
            </div>

            <div id="sidebar">
                <ul>
                    <a href="user_homepage.php">
                        <li class="sidebar-text"><img src="icons/home_icon.png" class="sidebar-icon">Home</li>
                    </a>
                    <a href="Change_Password_Interface.php">
                        <li class="sidebar-text"><img src="icons/password_icon.png" class="sidebar-icon">Change Password</li>
                    </a>
                    <a href="edit_profile_user.php">
                        <li class="sidebar-text"><img src="icons/password_icon.png" class="sidebar-icon">Edit Profile</li>
                     </a>
                    <a href="Add_Device_Interface.php">
                        <li class="sidebar-text"><img src="icons/add_device_icon.png" class="sidebar-icon">Add Device</li>
                    </a>
                    <a href="logout.php">
                        <li class="sidebar-text"><img src="icons/logout_icon.png" class="sidebar-icon">Sign Out</li>
                    </a>
                </ul>
            </div>

            <div id="rightside" align="left">

                <head>
                    <meta name="viewport" content="width=device-width, initial-scale=1">
                    <style>
                        .User {
                            background-color: skyblue;
                            color: white;
                            padding: 16px 155px;
                            margin: 5px 0;
                            border: none;
                            cursor: pointer;
                            width: -100%;
                            opacity: 0.9;
                        }

                        .User:hover {
                            opacity: 1;
                        }

                        .device {
                            background-color: dodgerblue;
                            color: white;
                            padding: 16px 20px;
                            margin: 5px 0;
                            border: none;
                            cursor: pointer;
                            width: 50%;
                            opacity: 0.9;
                        }

                        .device:hover {
                            opacity: 1;
                        }

                        input[type=text],
                        input[type=password] {
                            width: 95%;
                            padding: 15px;
                            margin: 5px 0 22px 0;
                            display: inline-block;
                            border: none;
                            background: #f1f1f1;
                        }

                    </style>
                </head>

                <body>

                    <form action="/action_page.php">
                        <div class="container">
                            <a href="Add_Device_Interface.php"><button type="button" class="device">Device</button></a>
                            <a href="Add_User_Interface.php"><button type="button" class="User">User</button></a>
                            <hr>

                            <label for="email"><b>User Name*:</b></label>
                            <input type="text" placeholder="Enter User Name" name="name" required>

                            <label for="email"><b>User ID*:</b></label>
                            <input type="number" placeholder="Enter User ID" name="id" required >

                            <button type="submit" name="submit" class="registerbtn">Add</button>
                        </div>


                    </form>

                </body>

            </div>
        </div>
    </div>

</body>

</html>
