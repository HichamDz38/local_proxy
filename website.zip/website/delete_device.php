<?php
    require "conn.php";
    $conn = mysqli_connect($server, $user , $pass, $database);
    // Checking for connection errors
    if (!$conn) {
        die($error = "Connection failed");
        echo "error";
    }else{
        $sql="SELECT * FROM device WHERE user_id='".$user_id."'";
        if($result=mysqli_query($conn,$sql)){
            while($row = mysqli_fetch_object($result)) {
                $did=$row->id;
                $mac=$row->MAC_address;
                $dstat=$row->Device_status;
                $dname=$row->device_name;
                echo "<tr>";
                echo "<td>‎".$dname."</td>";
                echo "<td>‎".$mac."</td>";
                echo "<td>‎".$dstat."</td>";
                echo "<td>‎</td>";
                echo "<td>‎<a href='delete_device.php?id=".$did."'>delete</a></td>";
                echo "</tr>";
            }
        } 

        $conn->close();
    }
?>