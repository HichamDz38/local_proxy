<?php
    $server = "localhost"; 
    $user = "proxy"; 
    $pass = "HciC0KeRXSSKzoDI"; 
    $database= "network_limiter1";
?>