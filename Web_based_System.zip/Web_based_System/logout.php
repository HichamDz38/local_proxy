<?php
    session_start();
    if(session_destroy()){
        header("location:loginPage_plus.php");
    }

?>